<div class="row page-title clearfix">
                <div class="page-title-left">
                    <h6 class="page-title-heading mr-0 mr-r-5">Hourly Load Reading Report</h6>
                    <!-- <p class="page-title-description mr-0 d-none d-md-inline-block">statistics, charts and events</p> -->
                </div>
                <!-- /.page-title-left -->
                <div class="page-title-right d-none d-sm-inline-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item active">Hourly Load Reading Report</li>
                    </ol>
                </div>
                <!-- /.page-title-right -->
            </div>


            <div class="widget-list">
                <div class="row">
                    <div class="col-md-12 widget-holder">
                        <div class="widget-bg">
                            <div class="widget-body clearfix">
                               
                                <!-- <h5 class="box-title mr-b-0">Horizontal Form</h5>
                                <p class="text-muted">All bootstrap element classies</p> -->
                                    <?php echo validation_errors('<div class="alert alert-danger mb-2">','</div>'); ?>
                                
                                    <form action="" method="POST">
                                         <div class="row">
                                     
                                             
                                             <div class="col-md-2">
                                                 <div class="radiobox radio-info">
                                              <label>
                                                  <input type="radio" class="feeder_type" name="asset_type" value="TS"> <span class="label-text"> 33KV FEEDER</span>
                                              </label>
                                              </div>
                                              </div>
                                              <div class="col-md-2">
                                                <div class="radiobox radio-info">
                                              <label>
                                                  <input type="radio" class="feeder_type" name="asset_type" value="ISS"> <span class="label-text "> 11KV FEEDER</span>
                                              </label>
                                              </div>
                                              </div>
                                       
                                        </div>
                                        <br/>
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                            <label class="col-form-label" for="year_input"> Choose Feeder</label>
                                           <select class="form-control" name="feeder_name" id="feeder_name">
                                                    
                                                    <?php
                                                        if (isset($search_params)) {
                                                            $feeder_name=$search_params['feeder_name'];
                                                        echo "<option value='".$feeder_name."'>".$feeder_name."</option>";
                                                        } else {
                                                           echo '<option value="">Choose Feeder</option>';
                                                        foreach ($feeders as $key => $value) {
                                                            ?>
                                                            <option 
                                                            value="<?= $value->feeder_name ?>"
                                                            
                                                                ><?= $value->feeder_name ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                        </div>
                                        </div>
                                        <!-- <div class="col-md-1"></div> -->
                                        <div class="col-md-3">
                                             <div class="form-group">
                                            <label class=" col-form-label"> Choose Date Type</label>
                                            <select class="form-control" name="dt" id="date_type">
                                                <option value="day" <?= isset($search_params)&&$search_params['dt']=="day"?'selected':'' ?>>Daily</option>
                                                <option <?= isset($search_params)&&$search_params['dt']=="month"?'selected':'' ?>  value="month">Monthly</option>
                                                
                                            </select>
                                                                                            
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                             <div class="form-group">
                                            <label class=" col-form-label" id="label_date" for="date_picker"> Choose day </label>
                                            <?php
                                            if (isset($search_params)) {
                                              if ($search_params['dt']=="day") {
                                                ?>
                                                <input class="form-control captured_date" value="<?= isset($search_params)?$search_params['date']:'' ?>" style="color: #333" type="text" name="captured_daily_date" id="captured_date" />

                                                 <input class="form-control date_picker" style="color: #333; display: none;" type="text" name="captured_month_date" id="date_picker" />

                                                <?php
                                              } elseif($search_params['dt']=="month") {
                                                ?>
                                                <input class="form-control captured_date date_picker" value="<?= isset($search_params)?$search_params['date']:'' ?>" style="color: #333" type="text" name="captured_month_date" id="date_picker" />

                                                <input class="form-control captured_date " style="color: #333;display: none;" type="text" name="captured_daily_date" id="captured_date" />
                                                <?php
                                              }

                                            }else{
                                              ?>
                                              <input class="form-control date_picker" style="color: #333; display: none;" type="text" name="captured_month_date" id="date_picker" />

                                                 <input class="form-control " value="<?= isset($search_params)?$search_params['date']:'' ?>" style="color: #333" type="text" name="captured_daily_date" id="captured_date" />
                                              <?php
                                            }
                                            ?>
                                                 
                                                                                            
                                            </div>
                                        </div>
                                        <input type="hidden" value="load" id="type">
                                        <input type="hidden" value="mis" id="page">
                                        <div class="col-md-3">
                                            
                                                <div class="form-group">
                                                    <label></label>
                                                    <div class=" ml-md-auto btn-list">
                                                        <button  class="btn btn-primary btn-rounded form-control" type="submit">Show Report</button>
                                                        
                                                    </div>
                                                
                                            </div>
                                        </div>
                                       
                                    </div>
                                   
                                  
                                </form>
                                    <hr/>
                                    <?php 


                                    if (isset($summary)) {
                                      //var_dump(sizeof((array)$summary));
                                      if (sizeof((array)$summary)<1) {
                                                echo "<div class='alert alert-danger'>No record Yet</div>";
                                            }
                                      ?>
                                      <center><h6 style="font-weight: bold;text-decoration: underline;" id="summary_title"><?= $title ?></h6></center>
                                      <br/><br/><br/>
                                      <?php
                                    }
                                    ?>
                    
                                <div id="barChart" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
                                <br/><br/>
                            <div id="lineChart" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
                            <br/><br/>
                                  <?php
                                        if (isset($summary)) {  
                                             // echo "<pre>";
                                             // print_r($search_params);
                                             // echo "</pre>";

                                            $date=day_date($dt,$month,$year);

                                    ?>
                                    <div id="report-container" >
                                        
                                        <p>
                                            <strong>
                                            <span class="text-info">Avg:</span><?= (isset($average))?$average->load:"0" ?> | 
                                            <span class="text-info">Min:</span><?= (isset($min))?$min->load .' | Day'. date("D d Y",strtotime($min->captured_at)):'0' ?>  |
                                            <span class="text-info">Max:</span><?= (isset($max))?$max->load.' | Day '.date("D d Y",strtotime($max->captured_at)):'0' ?>   | 
                                            <span class="text-info">Mode:</span><?= ((isset($mode)))?$mode->mode:'0' ?>
                                            </strong>
                                        </p>
                                        
                                       

                                        <div style="overflow-x: auto;" id="doublescroll">
                                        <table id="myTable" class="table table-bordered table-striped table-responsive" data-toggle="datatables" data-plugin-options='{"searching": true}'>
                                        <thead>
                                        <tr>
                                            <th>Hour</th>
                                           <?php
                                            foreach ($date as $key => $day) {
                                               ?>
                                               <th><?= $day; ?></th>
                                               <?php
                                            }
                                           ?> 
                                           <th>Hour</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                for ($hour=0; $hour <=23 ; $hour++) { 
                                                    ?>
                                                    <tr>
                                                        <td style="background: #556080;color: #ffffff">
                                                            <strong>
                                                                <?=  $hour==0?'00':$hour; ?>      
                                                            </strong>
                                                        </td>
                                                        <?php
                                                            foreach ($date as $key =>  $day) {
                                                               ?>
                                                               <td>
                    <?php
                   foreach ($summary as $report) {
                   
                    if ($dt=="month") {
                        //if is monthly
                        if ($report->hour==$hour && date("d",strtotime($report->captured_at))==$key+1) {
                        ?>
                        <?= $report->load ?></strong> 
                      
                       <?php 
                    } 
                    } else {
                        //is a day
                       if ($report->hour==$hour && date("d",strtotime($report->captured_at))==substr($day, 4)) {
                        ?>
                        <?= $report->load ?></strong> 
                      
                       <?php 
                    } 
                    }  
                     
                   }
                    
                   ?>
                 
                                </td>
                                                        <?php
                                                            }
                                                        ?>
                                                        <td style="background: #556080;color: #ffffff">
                                                            <strong>
                                                                <?=  $hour==0?'00':$hour; ?>      
                                                            </strong>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            ?>
                                        </tbody>
                                       <tfoot>
                                        <tr>
                                            <th>Hour</th>
                                           <?php
                                            foreach ($date as $key => $day) {
                                               ?>
                                               <th><?= $day; ?></th>
                                               <?php
                                            }
                                           ?> 
                                        </tr>
                                        </tfoot>
                                    </table>
                                    </div>
                                    </div>
                                <?php } ?>
                            <!-- this is section for summary -->
                            </div>
                            <!-- /.widget-body -->
                        </div>
                        <!-- /.widget-bg -->
                    </div>

                </div>
            </div>