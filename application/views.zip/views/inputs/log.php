<div class="row page-title clearfix">
                <div class="page-title-left">
                    <h6 class="page-title-heading mr-0 mr-r-5">Log Entry</h6>
                    <!-- <p class="page-title-description mr-0 d-none d-md-inline-block">statistics, charts and events</p> -->
                </div>
                <!-- /.page-title-left -->
                <div class="page-title-right d-none d-sm-inline-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item active">Log Entry</li>
                    </ol>
                </div>
                <!-- /.page-title-right -->
            </div>


            <div class="widget-list">
                <div class="row">
                    <div class="col-md-12 widget-holder">
                        <div class="widget-bg">
                            <div class="widget-body clearfix">
                               
                                <!-- <h5 class="box-title mr-b-0">Horizontal Form</h5>
                                <p class="text-muted">All bootstrap element classies</p> -->
                               <!-- <div class="alert alert-info">
                                    Choose TS or ISS
                                </div> -->
                                
                                <div style="">
                                <?php echo validation_errors('<div class="alert alert-danger mb-2">','</div>'); ?>
                                <form action="" method="POST">
                                    <div class="row">
                                         <?php
                                            if ($user->role_name=="admin") {
                                                //user is an admin
                                                ?>
                                                <input type="hidden" id="logType" value="load" name="">
                                                 <div class="col-md-3">
                                           <label> Select TS</label>
                                               <select class="form-control" name="trans_st" id="trans_st">
                                                    <option value="">Select Ts</option>
                                                    <?php
                                                        foreach ($ts_data as $key => $value) {
                                                            ?>
                                                            <option 
                                                            value="<?= $value->tsid ?>"
                                                            
                                                                ><?= $value->tsname ?></option>
                                                            <?php
                                                        }
                                                    ?>
                                                </select>

                                                <input type="hidden" id="station_id" name="station_id" >
                                                <input type="hidden" id="station_type" name="station_type">
                                            </div>
                                            <div></div>
                                                <div class="col-md-3">
                                                    <label>Or Select ISS</label>
                                            <select class="form-control" name="iss_name" id="iss_name">
                                                    <option value="">Select iss</option>
                                                    <?php
                                                        foreach ($iss_data as $key => $value) {
                                                            ?>
                                                            <option 
                                                            value="<?= $value->ISS_ID ?>"
                                                            
                                                                ><?= $value->ISS ?></option>
                                                            <?php
                                                        }
                                                    ?>
                                                </select>
                                        </div>
                                        
                                       
                                                <?php
                                            }else{
                                                //user is not admin
                                                ?>
                                                <div class="col-md-6">
                                                    <p>
                                                        <strong>
                                                            <?php
                                                                if ($user->station_type=="TS") {
                                                                    echo "Transmission Station: ".$station->tsname;
                                                                } else {
                                                                   echo "ISS: ".$station->ISS;

                                                                }
                                                                
                                                            ?>
                                                        
                                                        </strong>
                                                    </p>
                                                    <input type="hidden" id="station_id" value="<?= $user->station_name ?>" name="station_id">
                                           <input type="hidden" id="station_type" name="station_type" value="<?= $user->station_type ?>">
                                                </div>
                                                <?php
                                            }
                                    
                                        ?>
                                        
                                        
                                        <!-- <div class="col-md-1"></div> -->
                                        <div class="col-md-3">
                                           
                                                <!-- <input required class="form-control" style="color: #333" type="text" name="captured_date" id="captured_date" /> -->
                                                <label>Select Hour</label>
                                                  <select required class="form-control" name="hour" id="hour">
                                                    <option value="">Select hour</option>
                                                    <?php
                                                        for ($i=0; $i <=23 ;$i++) {
                                                            ?>
                                                            <option 
                                                            value="<?= $i ?>"
                                                            
                                                                ><?= ($i==0)?'00':$i ?></option>
                                                            <?php
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                           
                                          
                                                <!-- <input required class="form-control" style="color: #333" type="text" name="captured_date" id="captured_date" /> -->
                                                <label>Select Date</label>
                                                <input required class="form-control" style="color: #333" placeholder="Select date" type="text" name="captured_date" id="captured_date" />
                                            </div>
                                            
                                    </div>
                                    <table class="my-3 table table-striped table-responsive" >
                                        <thead>
                                            <tr>
                                                <th>Feeder</th>
                                                <th>Load(MW)</th>
                                                <th>Power factor(PF)</th>
                                                <th>Voltage(V)</th>
                                                <th>Current(AMP)</th>
                                                <th>Frequency(F)</th>
                                                <th>Remarks(optional)</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody id="tbody">
                                            <?php
                                                if (isset($feeders)) {
                                                    if ($user->station_type=="TS") {
                                                        foreach ($feeders as $key => $feeder) {
                                                       ?>
                                                       <tr>
                                                           <td>
                                                            <?= $feeder->feeder_name ?>
                                                            <input type='hidden' value='<?= $feeder->feeder_name ?>' name='feeders[]'/>    
                                                            </td>
                                                            <td>
                                                                <input name='readings[]' type='text' class='form-control' />
                                                            </td>
                                                            <td><input name='remarks[]' type='text' class='form-control' /></td>
                                                       </tr>
                                                       <?php
                                                   }
                                                    } else {
                                                        foreach ($feeders as $key => $feeder) {
                                                       ?>
                                                       <tr>
                                                           <td>
                                                            <?= $feeder->feeder_name_11 ?>
                                                            <input type='hidden' value='<?= $feeder->feeder_name_11 ?>' name='feeders[]'/>    
                                                            </td>
                                                            <td>
                                                                <input name='readings[]' type='text' class='form-control' />
                                                            </td>
                                                            <td><input name='remarks[]' type='text' class='form-control' /></td>
                                                       </tr>
                                                       <?php
                                                   }
                                                    }
                                                    
                                                   
                                                }
                                            ?>
                                         <!-- <td>
                                                <h4 >No IBC chosen</h4>
                                            </td> -->
                                            
                                             <!--  <script id="feeder_temp" type="template">
                                                <tr>
                                                    <td>{{feeder_name}}</td>
                                                    <td><input type="text" name="readings[]" /></td>
                                                    
                                                </tr>
                                            </script> -->
                                        </tbody>

                                    </table>
                                    <hr/>
                                    <!--  <div class="form-group row">
                                            <label class="col-md-3 col-form-label" for="captured_date"> Remarks</label>
                                            <div class="col-md-9">
                                               <textarea class="form-control" placeholder="Optional" name="remarks" cols="4"></textarea>
                                            </div>
                                            
                                            </div> -->
                                    <div class="form-actions" style="display: none;" id="button-container">
                                        <div class="form-group ">
                                            <div class="">
                                                <button id="btn" class="btn btn-primary btn-rounded" type="submit">Log</button>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>


                            <!-- this is section for summary -->
                            </div>
                            <!-- /.widget-body -->
                        </div>
                        <!-- /.widget-bg -->
                    </div>

                </div>
            </div>