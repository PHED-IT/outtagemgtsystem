<div class="row page-title clearfix">
                <div class="page-title-left">
                    <h6 class="page-title-heading mr-0 mr-r-5">Edit log sheet</h6>
                    <!-- <p class="page-title-description mr-0 d-none d-md-inline-block">statistics, charts and events</p> -->
                </div>
                <!-- /.page-title-left -->
                <div class="page-title-right d-none d-sm-inline-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item active">Edit log sheet</li>
                    </ol>
                </div>
                <!-- /.page-title-right -->
            </div>


            <div class="widget-list">
                <div class="row">
                    <div class="col-md-12 widget-holder">
                        <div class="widget-bg">
                            <div class="widget-body clearfix">
                               
                                <!-- <h5 class="box-title mr-b-0">Horizontal Form</h5>
                                <p class="text-muted">All bootstrap element classies</p> -->
                                    <?php echo validation_errors('<div class="alert alert-danger mb-2">','</div>'); ?>
                                
                                    <form action="" method="POST">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                            <label class=" col-form-label" for="year_input"> Choose Feeder</label>
                                        <div class="">
                                              
                                           <select class="form-control" name="feeder_name" id="feeder_name">
                                                    <option value="">Choose Feeder</option>
                                                    <?php
                                                        foreach ($feeders as $key => $value) {
                                                            ?>
                                                            <option 
                                                            value="<?= $value->feeder_name ?>"
                                                            
                                                                ><?= $value->feeder_name ?></option>
                                                            <?php
                                                        }
                                                    ?>
                                                </select>
                                        </div>
                                        </div>
                                        </div>
                                         <div class="col-md-3">
                                            <div class="form-group">
                                            <label class=" col-form-label" for="year_input"> Choose Type</label>
                                        <div class="">
                                              
                                           <select class="form-control" name="log_type" id="type">
                                                    <option value="">Choose type</option>
                                                   <option value="load">Load</option>
                                                   <option value="current">Current</option>
                                                   <option value="pf">Power Factor</option>
                                                   <option value="frequency">Frequency</option>
                                                   <option value="voltage">Voltage</option>
                                                   <option value="energy">Energy</option>
                                                </select>
                                        </div>
                                        </div>
                                        </div>
                                        <!-- <div class="col-md-1"></div> -->
                                        <div class="col-md-3">
                                             <div class="form-group">
                                            <label class="col-form-label" for="date_picker"> Choose Date</label>
                                            <div class="">
                                                <input placeholder="Choose date" class="form-control date_picker" style="color: #333" type="text" name="captured_date" id="date_picker" />
                                                  
                                            </div>
                                            
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            
                                                <div class="form-group ">
                                                    <label style="color: #ffffff" class="col-form-label" for="date_picker"> .</label>
                                                        <button  class="btn btn-primary btn-rounded form-control" type="submit">Show Log</button>
                                            </div>
                                        </div>
                                       
                                    </div>
                                   
                                  
                                </form>
                                    <hr/>

                                    <?php
                                        if (isset($summary)) {  
                                            
                                             // echo "<pre>";
                                             // print_r($max);
                                             // echo "</pre>";
                                            //var_dump($summary);
                                            $date=day_date($dt,$month,$year);
                                            // var_dump($summary);
                                            // if (count((array)$summary)<1) {
                                            //     echo "<div class='alert alert-danger'>No record Yet</div>";
                                            // }

                                    ?>
                                    <div id="report-container" >
                                        <h6 style="font-weight: bold" id="summary_title"><?= $title ?></h6>
                                     
                                        <div style="overflow-x: auto;" id="doublescroll">
                                        <table class="table table-bordered table-striped table-responsive" data-toggle="datatables" data-plugin-options='{"searching": true}'>
                                        <thead>
                                        <tr>
                                            <th>Hour</th>
                                           <?php
                                            foreach ($date as $key => $day) {
                                               ?>
                                               <th><?= $day; ?></th>
                                               <?php
                                            }
                                           ?> 
                                           <th>Hour</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                for ($hour=0; $hour <=23 ; $hour++) { 
                                                    ?>
                                                    <tr>
                                                        <td style="background: #556080;color: #ffffff">
                                                            <strong>
                                                                <?=  $hour==0?'00':$hour; ?>      
                                                            </strong>
                                                        </td>
                    <?php
                    foreach ($date as $key =>  $day) {
                       ?>
                    <td>
                    <?php
                   foreach ($summary as $report) {
                    //echo  $hour;
                    if ($report->hour==$hour && date("d",strtotime($report->captured_at))==$key+1) {

                        if($log_type=='load' && !empty($report->load)){
                            ?>
                            <button data-toggle="modal" class="btn-td" data-target="#modal<?= $report->id ?>"><strong id="data<?= $report->id ?>">
                                <?= $report->load  ?>
                            </strong>
                            </button>
                            <?php
                        }elseif ($log_type=='current' && !empty($report->current)) {
                            ?>
                             <button data-toggle="modal" class="btn-td" data-target="#modal<?= $report->id ?>"><strong id="data<?= $report->id ?>">
                                <?= $report->current  ?>
                            </strong>
                            </button>
                            <?php
                        }elseif ($log_type=='pf' && !empty($report->pf)) {
                            ?>
                             <button data-toggle="modal" class="btn-td" data-target="#modal<?= $report->id ?>"><strong id="data<?= $report->id ?>">
                                <?= $report->pf  ?>
                            </strong>
                            </button>
                            <?php
                        }elseif ($log_type=='frequency' && !empty($report->frequency)) {
                            ?>
                             <button data-toggle="modal" class="btn-td" data-target="#modal<?= $report->id ?>"><strong id="data<?= $report->id ?>">
                                <?= $report->frequency  ?>
                            </strong>
                            </button>
                            <?php
                        }elseif ($log_type=='energy' && !empty($report->energy)) {
                            ?>
                             <button data-toggle="modal" class="btn-td" data-target="#modal<?= $report->id ?>"><strong id="data<?= $report->id ?>">
                                <?= $report->energy  ?>
                            </strong>
                            </button>
                            <?php
                        }elseif ($log_type=='voltage' && !empty($report->voltage)) {
                            ?>
                             <button data-toggle="modal" class="btn-td" data-target="#modal<?= $report->id ?>"><strong id="data<?= $report->id ?>">
                                <?= $report->voltage  ?>
                            </strong>
                            </button>
                            <?php
                        }

                        ?>

                        
                        <!-- Edit modal -->
                          <div class="modal fade" id="modal<?= $report->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">
            <form class="update-reading" id="<?= $report->id ?>">
                <input type="hidden" value="<?= $report->id ?>" name="reading_id">
                <input type="hidden" value="<?= $log_type ?>" name="type">
              <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                        <label class="col-md-5 col-form-label" for="reading"> <?= $log_type ?></label>
                        <?php 
                            // $log_type=strtolower($log_type);
                            // $type=$log_type=='load'?'reading':$log_type;
                            //echo $type;
                        ?>
                        <input type="number" class="form-control" name="reading" id="reading" value="<?= $report->$log_type ?>">
                        
                    </div>
                    </div>
                </div>
                <div>
                    <!-- <div class="col-md-1"></div> -->
                    <div class="col-md-12">
                        <div class="form-group">
                        <label class="col-form-label" for="remarks"> Remark</label>
                        <textarea class="form-control" placeholder="Optional" name="remarks" id="remarks" cols="4"><?= $report->remarks ?></textarea>
                        </div>
                    </div>
                    <div class="form-actions"  id="button-containers">
                        <button id="btn<?= $report->id ?>" class="btn btn-primary btn-rounded" type="submit">Edit</button>
                    </div>
            </div>
        </form>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
           
          </div>
        </div>
      </div>
    </div>
                       <?php 
                    }  
                   }
                    
                   ?>
                 
                                                               </td>
                                                        <?php
                                                            }
                                                        ?>
                                                        <td style="background: #556080;color: #ffffff">
                                                            <strong>
                                                                <?=  $hour==0?'00':$hour; ?>      
                                                            </strong>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            ?>
                                        </tbody>
                                       <tfoot>
                                        <tr>
                                            <th>Hour</th>
                                           <?php
                                            foreach ($date as $key => $day) {
                                               ?>
                                               <th><?= $day; ?></th>
                                               <?php
                                            }
                                           ?> 
                                        </tr>
                                        </tfoot>
                                    </table>
                                    </div>
                                    </div>
                                <?php } ?>
                            <!-- this is section for summary -->
                            </div>
                            <!-- /.widget-body -->
                        </div>
                        <!-- /.widget-bg -->
                    </div>

                </div>
            </div>