<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Input extends My_Controller
{
	
	public function index(){
		$this->form_validation->set_rules('captured_date','Captured Date',"required");
		$this->form_validation->set_rules('hour','Captured Hour',"required");
		$this->form_validation->set_rules('readings[]','Reading',"required|numeric");
		//$this->input_model->insert_bot();
		if ($this->form_validation->run()==FALSE) {
		$data['ts_data']=$this->input_model->get_transmission_stations();
		$data['iss_data']=$this->input_model->get_iss();
		$data['user']=$this->admin_model->get_user($this->session->userdata('USER_ID'));
		
		$data['station']=$this->input_model->get_station($data['user']);
		$data['feeders']=$this->input_model->get_feeder_station($data['user']);
		//$data['last_reading']=$this->input_model->get_last_reading(date('Y-m-d',strtotime("now")));
		$data['title']="Log enrty sheet";
		//$data['summary']=$this->input_model->get_ibc_summary();
		$this->load->view('Layouts/header',$data);
		$this->load->view('inputs/log',$data);
		$this->load->view('Layouts/footer');
		//echo $this->session->userdata('USER_ID');
	}else{
		//var_dump($this->input->post('reading'));
		$insert_data=array("feeders"=>$this->input->post('feeders'),'readings'=>$this->input->post('readings'),'voltage'=>$this->input->post('voltage'),'pf'=>$this->input->post('pf'),'current'=>$this->input->post('current'),'frequency'=>$this->input->post('frequency'),'hour'=>$this->input->post('hour'),'created_by'=>$this->session->userdata('USER_ID'),'remarks'=>$this->input->post('remarks'),'station_id'=>$this->input->post('station_id'),'station_type'=>$this->input->post('station_type'),'captured_date'=>$this->input->post('captured_date'));

		$result=$this->input_model->store_log($insert_data);
			if ($result['status']) {
				$this->session->set_flashdata('success',"Log created successfully");
				redirect('input/');
			} else {
				$this->session->set_flashdata('error',$result['data']);
				redirect('input/');
			}
	}
	}

	public function energy(){
		$this->form_validation->set_rules('captured_date','Captured Date',"required");
		$this->form_validation->set_rules('hour','Captured Hour',"required");
		$this->form_validation->set_rules('energy[]','Reading',"required|numeric");
		if ($this->form_validation->run()==FALSE) {
		$data['ts_data']=$this->input_model->get_transmission_stations();
		$data['iss_data']=$this->input_model->get_iss();
		$data['user']=$this->admin_model->get_user($this->session->userdata('USER_ID'));
		
		$data['station']=$this->input_model->get_station($data['user']);
		$data['feeders']=$this->input_model->get_feeder_station($data['user']);
		$data['title']="Energy log sheet";
		//$data['summary']=$this->input_model->get_ibc_summary();
		$this->load->view('Layouts/header',$data);
		$this->load->view('inputs/energy',$data);
		$this->load->view('Layouts/footer');
		//echo $this->session->userdata('USER_ID');
	}else{
		//var_dump($this->input->post('reading'));
		$insert_data=array("feeders"=>$this->input->post('feeders'),'energy'=>$this->input->post('energy'),'hour'=>$this->input->post('hour'),'created_by'=>$this->session->userdata('USER_ID'),'remarks'=>$this->input->post('remarks'),'station_id'=>$this->input->post('station_id'),'station_type'=>$this->input->post('station_type'),'captured_date'=>$this->input->post('captured_date'));

		$result=$this->input_model->store_energy($insert_data);
			if ($result['status']) {
				$this->session->set_flashdata('success',"Log created successfully");
				redirect('input/energy');
			} else {
				$this->session->set_flashdata('error',$result['data']);
				redirect('input/energy');
			}
	}
	}

	// public function edit_reading($feeder_name){
	// 	$this->form_validation->set_rules('readings[]','Reading',"required|numeric");
	// 	if ($this->form_validation->run()==FALSE){
	// 		$feeder_name=urldecode(str_replace("-", " ", $feeder_name));
	// 		$data['input_data']=$this->input_model->get_inputs_feeder($feeder_name);
	// 		$data['feeder_name']=$feeder_name;
	// 		$data['title']="Edit reading for ".$feeder_name;
	// 		$this->load->view('Layouts/header',$data);
	// 		$this->load->view('inputs/edit_reading',$data);
	// 		$this->load->view('Layouts/footer');
	// 	}else{
	// 		$insert_data=array("ibc_name"=>$this->input->post('ibc_name'),"feeder_name"=>$this->input->post('feeder_name'),'readings'=>$this->input->post('readings'),'prev_readings'=>$this->input->post('prev_readings'),'created_at'=>$this->input->post('created_at'));

	// 		 $result=$this->input_model->update_reading_ibc_feeader($insert_data);
	// 		 //echo $result;
	// 		if ($result['status']) {
	// 			$this->session->set_flashdata('success',"Reading updated successfully");
	// 			redirect('input/edit_reading/'.$feeder_name);
	// 		} else {
	// 			$this->session->set_flashdata('error',$result['data']);
	// 			redirect('input/edit_reading/'.$feeder_name);
	// 		}
	// 	}
		
	// }
	// public function get_feeders_ibc(){
	// 	$ibc_name=$this->input->post('ibc_name');
	// 	$feaders=$this->input_model->get_feeders_ibc($ibc_name);
	// 	echo json_encode($feaders);
	// }
	public function get_feeders_ts(){
		$trans_st=$this->input->post('trans_st');
		$feaders=$this->input_model->get_feeders_ts($trans_st);
		echo json_encode($feaders);
	}
	public function get_feeder_iss(){
		$iss_name=$this->input->post('iss_name');
		$feaders=$this->input_model->get_feeder_iss($iss_name);
		echo json_encode($feaders);
	}
	public function edit_log(){
		$this->form_validation->set_rules('captured_date','DATE',"required");
		$this->form_validation->set_rules('feeder_name','FEEDER NAME',"required");
		$this->form_validation->set_rules('log_type','LOG TYPE',"required");
		if ($this->form_validation->run()==FALSE){
			$data['title']="Edit Log";
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('inputs/edit_log_sheet',$data);
			$this->load->view('Layouts/footer');
		}else{
			$date=$this->input->post('captured_date');
			$log_type=$this->input->post('log_type');
			
			$insert_data=array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$this->input->post('captured_date'),"log_type"=>$this->input->post('log_type'));
			$month=substr($date, 0,2);
			$year=substr($date, 3,6);

			$data['summary']=$this->input_model->get_reading_feeder_date($insert_data);
			$data['month']=$month;
			$data['year']=$year;
			$data['dt']="month";
			$data['log_type']=$log_type;
			$data['title']=strtoupper($log_type)." Report for ".$this->input->post('feeder_name')." ".$date;
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('inputs/edit_log_sheet',$data);
			$this->load->view('Layouts/footer');
		}
		
	}
	public function get_reading_date(){
		$day=$this->input->post('day');
		$month=$this->input->post('month');
		$year=$this->input->post('year');

		$record=$this->input_model->get_reading_date($day,$month,$year);
		echo json_encode($record);
	}

	public function update_reading(){
		$insert_data=array("remarks"=>$this->input->post('remarks'),"reading"=>$this->input->post('reading'),"reading_id"=>$this->input->post('reading_id'),'type'=>$this->input->post('type'));
		$result=$this->input_model->update_reading($insert_data);
			 //echo $result;
		echo json_encode($result);
	}

	public function get_stations(){
		$type=$this->input->post('station_type');
		if ($type=="TS") {
			$result=$this->input_model->get_transmission_stations();
		} else {
			$result=$this->input_model->get_iss();
		}
		echo json_encode($result);	
	}

}







?>