<?php

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Mis extends MY_Controller
{
	public function index(){

	}
	public function load_report(){
		//$this->form_validation->set_rules('captured_date','DATE',"required");
		$this->form_validation->set_rules('feeder_name','FEEDER NAME',"required");
		
		if ($this->form_validation->run()==FALSE){
			$data['title']="Hourly Reading Report";
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/load_report',$data);
			$this->load->view('Layouts/footer');
		}else{
			$date=$this->input->post('captured_month_date')?$this->input->post('captured_month_date'):$this->input->post('captured_daily_date');
			$dt=$this->input->post('dt');
			
			$insert_data=array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$date,'type'=>"load","dt"=>$dt);
			
			if ($dt=="day") {
				$month=substr($date, 5,7);
				$year=substr($date, 0,4);
			} elseif($dt=="month") {
				$month=substr($date, 0,2);
				$year=substr($date, 3,6);
			}
			
			$data['search_params']=array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$date,'dt'=>$dt);

			$data['summary']=$this->mis_model->get_log_sheet($insert_data);
			$data['average']=$this->mis_model->get_reading_avg($insert_data);
			$data['min']=$this->mis_model->get_reading_min($insert_data);
			$data['max']=$this->mis_model->get_reading_max($insert_data);
			$data['mode']=$this->mis_model->get_reading_mode($insert_data);
			$data['month']=$month;
			$data['year']=$year;
			$data['dt']=$dt;
			$data['title']="HOURLY LOAD REPORT FOR ".strtoupper($this->input->post('feeder_name'))." ".strtoupper($date);
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/load_report',$data);
			$this->load->view('Layouts/footer');
		}
		
	}
	public function current_report(){
		//$this->form_validation->set_rules('captured_date','DATE',"required");
		$this->form_validation->set_rules('feeder_name','FEEDER NAME',"required");
		
		if ($this->form_validation->run()==FALSE){
			$data['title']="Hourly Current Report";
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/current_report',$data);
			$this->load->view('Layouts/footer');
		}else{
			$date=$this->input->post('captured_month_date')?$this->input->post('captured_month_date'):$this->input->post('captured_daily_date');
			$dt=$this->input->post('dt');
			
			$insert_data=array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$date,'type'=>"current","dt"=>$dt);
			if ($dt=="day") {
				$month=substr($date, 5,7);
				$year=substr($date, 0,4);
			} elseif($dt=="month") {
				$month=substr($date, 0,2);
				$year=substr($date, 3,6);
			}
			$data['search_params']=array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$date,'dt'=>$dt);

			$data['summary']=$this->mis_model->get_log_sheet($insert_data);
			$data['average']=$this->mis_model->get_reading_avg($insert_data);
			$data['min']=$this->mis_model->get_reading_min($insert_data);
			$data['max']=$this->mis_model->get_reading_max($insert_data);
			$data['mode']=$this->mis_model->get_reading_mode($insert_data);
			$data['month']=$month;
			$data['year']=$year;
			$data['dt']=$dt;
			$data['title']="HOURLY CURRENT REPORT FOR ".$this->input->post('feeder_name')." ".strtoupper($date);
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/current_report',$data);
			$this->load->view('Layouts/footer');
		}
		
	}
	public function pf_report(){
		//$this->form_validation->set_rules('captured_date','DATE',"required");
		$this->form_validation->set_rules('feeder_name','FEEDER NAME',"required");
		
		if ($this->form_validation->run()==FALSE){
			$data['title']="Hourly PF Report";
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/pf_report',$data);
			$this->load->view('Layouts/footer');
		}else{
			$date=$this->input->post('captured_month_date')?$this->input->post('captured_month_date'):$this->input->post('captured_daily_date');
			$dt=$this->input->post('dt');
			
			$insert_data=array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$date,'type'=>"pf","dt"=>$dt);
			if ($dt=="day") {
				$month=substr($date, 5,7);
				$year=substr($date, 0,4);
			} elseif($dt=="month") {
				$month=substr($date, 0,2);
				$year=substr($date, 3,6);
			}
			$data['search_params']=array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$date,'dt'=>$dt);


			$data['summary']=$this->mis_model->get_log_sheet($insert_data);
			$data['average']=$this->mis_model->get_reading_avg($insert_data);
			$data['min']=$this->mis_model->get_reading_min($insert_data);
			$data['max']=$this->mis_model->get_reading_max($insert_data);
			$data['mode']=$this->mis_model->get_reading_mode($insert_data);
			$data['month']=$month;
			$data['year']=$year;
			$data['dt']=$dt;
			$data['title']="Hourly PF Report for ".$this->input->post('feeder_name')." ".$date;
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/pf_report',$data);
			$this->load->view('Layouts/footer');
			

		}
		
	}
	public function frequency(){
		//$this->form_validation->set_rules('captured_date','DATE',"required");
		$this->form_validation->set_rules('feeder_name','FEEDER NAME',"required");
		
		if ($this->form_validation->run()==FALSE){
			$data['title']="Hourly frequency Report";
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/frequency_report',$data);
			$this->load->view('Layouts/footer');
		}else{
			$date=$this->input->post('captured_month_date')?$this->input->post('captured_month_date'):$this->input->post('captured_daily_date');
			$dt=$this->input->post('dt');
			
			$insert_data=array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$date,'type'=>"frequency","dt"=>$dt);
			if ($dt=="day") {
				$month=substr($date, 5,7);
				$year=substr($date, 0,4);
			} elseif($dt=="month") {
				$month=substr($date, 0,2);
				$year=substr($date, 3,6);
			}
			$data['search_params']=array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$date,'dt'=>$dt);


			$data['summary']=$this->mis_model->get_log_sheet($insert_data);
			$data['average']=$this->mis_model->get_reading_avg($insert_data);
			$data['min']=$this->mis_model->get_reading_min($insert_data);
			$data['max']=$this->mis_model->get_reading_max($insert_data);
			$data['mode']=$this->mis_model->get_reading_mode($insert_data);
			$data['month']=$month;
			$data['year']=$year;
			$data['dt']=$dt;
			$data['title']="HOURLY FREQUENCY REPORT FOR ".$this->input->post('feeder_name')." ".$date;
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/frequency_report',$data);
			$this->load->view('Layouts/footer');
		}
		
	}
	public function energy_report(){
		//$this->form_validation->set_rules('captured_date','DATE',"required");
		$this->form_validation->set_rules('feeder_name','FEEDER NAME',"required");
		
		if ($this->form_validation->run()==FALSE){
			$data['title']="Energy Report";
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/energy_report',$data);
			$this->load->view('Layouts/footer');
		}else{
			$date=$this->input->post('captured_month_date')?$this->input->post('captured_month_date'):$this->input->post('captured_daily_date');
			$dt=$this->input->post('dt');
			
			$insert_data=array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$date,'type'=>"energy","dt"=>$dt);
			if ($dt=="day") {
				$month=substr($date, 5,7);
				$year=substr($date, 0,4);
			} elseif($dt=="month") {
				$month=substr($date, 0,2);
				$year=substr($date, 3,6);
			}
			$data['search_params']=array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$date,'dt'=>$dt);
			$data['summary']=$this->mis_model->get_log_sheet($insert_data);
			$data['average']=$this->mis_model->get_reading_avg($insert_data);
			$data['min']=$this->mis_model->get_reading_min($insert_data);
			$data['max']=$this->mis_model->get_reading_max($insert_data);
			$data['mode']=$this->mis_model->get_reading_mode($insert_data);
			$data['month']=$month;
			$data['year']=$year;
			$data['dt']=$dt;
			$data['title']="Energy Report for ".$this->input->post('feeder_name')." ".$date;
			$data['feeders']=$this->input_model->get_feeders();
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/energy_report',$data);
			$this->load->view('Layouts/footer');
			

		}	
	}
	
	public function get_log_feeder_type(){
		$type=$this->input->post('type');
		$feaders=$this->mis_model->get_log_feeder_type($type);
		echo json_encode($feaders);
	}
	public function get_chart_data(){
		$type=$this->input->post('type');
		$data=$this->mis_model->get_chat_data(array("feeder_name"=>$this->input->post('feeder_name'),"date"=>$this->input->post('date'),"dt"=>$this->input->post('dt'),'type'=>$this->input->post('type')));
		echo json_encode($data);
	}

	public function fault_cause(){
		$this->form_validation->set_rules('asset_type','ASSET TYPE',"required");
		$this->form_validation->set_rules('asset_name','ASSET NAME',"required");
		$this->form_validation->set_rules('date','Date',"required");
		//$data['trippings']=$this->tripping_model->get_interupted_trippings();
		if ($this->form_validation->run()==FALSE){
		$data['title']="FAULT BY CAUSE REPORT";
		//$data['feeders']=$this->tripping_model->get_all_feeders();
		//$data['faults']=$this->tripping_model->get_fault_interrupt();
		$this->load->view('Layouts/header',$data);
		$this->load->view('mis/fault_cause',$data);
		$this->load->view('Layouts/footer');
		}else{
			list($start_date,$end_date)=explode(" - ", $this->input->post('date'));
			$insert_data=array("asset_name"=>$this->input->post('asset_name'),"start_date"=>date("Y-m-d",strtotime($start_date)),"end_date"=>date("Y-m-d",strtotime($end_date)),'asset_type'=>$this->input->post('asset_type'));
			$result=$this->mis_model->get_fault_cause_report($insert_data);
			if ($this->input->post('asset_name')=='') {
				$data['title']="FAULT BY CAUSE REPORT FOR ".$this->input->post('asset_type')."  BETWEEN ".$start_date." AND ".$end_date;
			}else{
				$data['title']="FAULT BY CAUSE REPORT FOR ".$this->input->post('asset_name')."  BETWEEN ".$start_date." AND ".$end_date;
			}
			
			
			$data['report']=$result;
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/fault_cause',$data);
			$this->load->view('Layouts/footer');
			
		}
	}


	public function cause_asset_report(){
		$this->form_validation->set_rules('asset_type','ASSET TYPE',"required");
		//$this->form_validation->set_rules('asset_name','ASSET NAME',"required");
		$this->form_validation->set_rules('date','Date',"required");
		//$data['trippings']=$this->tripping_model->get_interupted_trippings();
		if ($this->form_validation->run()==FALSE){
		$data['title']="CAUSE OF FAULT BY ASSET REPORT";
		//$data['feeders']=$this->tripping_model->get_all_feeders();
		//$data['faults']=$this->tripping_model->get_fault_interrupt();
		$this->load->view('Layouts/header',$data);
		$this->load->view('mis/cause_asset_report',$data);
		$this->load->view('Layouts/footer');
		}else{
			list($start_date,$end_date)=explode(" - ", $this->input->post('date'));
			$insert_data=array("asset_name"=>$this->input->post('asset_name'),"start_date"=>date("Y-m-d",strtotime($start_date)),"end_date"=>date("Y-m-d",strtotime($end_date)),'asset_type'=>$this->input->post('asset_type'));
			$result=$this->mis_model->get_cause_asset_report($insert_data);
			if ($this->input->post('asset_name')=='') {
				$data['title']="CAUSE OF FAULT REPORT FOR ".$this->input->post('asset_type')."  BETWEEN ".$start_date." AND ".$end_date;
			}else{
				$data['title']="CAUSE OF FAULT REPORT FOR ".$this->input->post('asset_name')."  BETWEEN ".$start_date." AND ".$end_date;
			}
			
			
			$data['report']=$result;
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/cause_asset_report',$data);
			$this->load->view('Layouts/footer');
			
		}
	}
	public function indication_asset_report(){
		$this->form_validation->set_rules('asset_type','ASSET TYPE',"required");
		//$this->form_validation->set_rules('asset_name','ASSET NAME',"required");
		$this->form_validation->set_rules('date','Date',"required");
		//$data['trippings']=$this->tripping_model->get_interupted_trippings();
		if ($this->form_validation->run()==FALSE){
		$data['title']=" FAULT INDICATION BY ASSET REPORT";
		//$data['feeders']=$this->tripping_model->get_all_feeders();
		//$data['faults']=$this->tripping_model->get_fault_interrupt();
		$this->load->view('Layouts/header',$data);
		$this->load->view('mis/indication_asset_report',$data);
		$this->load->view('Layouts/footer');
		}else{
			list($start_date,$end_date)=explode(" - ", $this->input->post('date'));
			$insert_data=array("asset_name"=>$this->input->post('asset_name'),"start_date"=>date("Y-m-d",strtotime($start_date)),"end_date"=>date("Y-m-d",strtotime($end_date)),'asset_type'=>$this->input->post('asset_type'));
			$result=$this->mis_model->get_indication_asset_report($insert_data);
			if ($this->input->post('asset_name')=='') {
				$data['title']="FAULT INIDICATION REPORT FOR  ".$this->input->post('asset_type')."  BETWEEN ".$start_date." AND ".$end_date;
			}else{
				$data['title']="FAULT INIDICATION REPORT FOR ".$this->input->post('asset_name')."  BETWEEN ".$start_date." AND ".$end_date;
			}
			
			
			$data['report']=$result;
			$this->load->view('Layouts/header',$data);
			$this->load->view('mis/fault_cause',$data);
			$this->load->view('Layouts/footer');
			
		}
	}
	public function report(){
		
		//$this->form_validation->set_rules('asset_name','Name',"required");
		$this->form_validation->set_rules('asset_type','Type',"required");
		$this->form_validation->set_rules('date','Date',"required");
		//$data['trippings']=$this->tripping_model->get_interupted_trippings();
		if ($this->form_validation->run()==FALSE){
		$data['title']="Report";
		//$data['feeders']=$this->tripping_model->get_all_feeders();
		$data['faults']=$this->tripping_model->get_fault_interrupt();
		$this->load->view('Layouts/header',$data);
		$this->load->view('trippings/report',$data);
		$this->load->view('Layouts/footer');
		}else{
			list($start_date,$end_date)=explode(" - ", $this->input->post('date'));
			$insert_data=array("asset_id"=>$this->input->post('asset_name'),"start_date"=>date("Y-m-d",strtotime($start_date)),"end_date"=>date("Y-m-d",strtotime($end_date)),"fault_id"=>$this->input->post('fault_id'),'type'=>$this->input->post('asset_type'));
			$result=$this->tripping_model->report($insert_data);
			if ($this->input->post('asset_name')=='') {
				$data['title']="Fault report for ".$this->input->post('asset_type')."  between ".$start_date." and ".$end_date;
			}else{
				$data['title']="Fault report for ".$this->input->post('asset_name')."  between ".$start_date." and ".$end_date;
			}
			
			$data['faults']=$this->tripping_model->get_fault_interrupt();
			$data['report']=$result;
			$this->load->view('Layouts/header',$data);
			$this->load->view('trippings/report',$data);
			$this->load->view('Layouts/footer');
			
		}

	}
}